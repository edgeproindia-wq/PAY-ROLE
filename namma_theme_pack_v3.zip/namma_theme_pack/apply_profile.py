"""Adds the round profile photo + profile menu at the top right (safe to run twice)."""
import ast, pathlib, re, shutil, subprocess, sys, datetime

PACK = pathlib.Path(__file__).resolve().parent
FILES = PACK / 'files'
APP = pathlib.Path('payroll_app')


def fail(msg):
    print('NOTHING FINISHED:', msg); sys.exit(1)


if not pathlib.Path('manage.py').exists() or not APP.is_dir():
    fail('run this from the folder that has manage.py')


def read(p):
    raw = p.read_bytes().decode('utf-8-sig')
    return raw, '\r\n' in raw, raw.replace('\r\n', '\n')


def write(p, text, crlf):
    p.write_bytes((text.replace('\n', '\r\n') if crlf else text).encode('utf-8'))


bdir = pathlib.Path('backups') / ('profile_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
bdir.mkdir(parents=True, exist_ok=True)

for name in ('profile_photo_models.py', 'profile_photo.py', 'tests_profile.py'):
    shutil.copy2(FILES / name, APP / name)
(APP / 'templates' / 'profile').mkdir(parents=True, exist_ok=True)
shutil.copy2(FILES / 'profile_templates' / 'my_profile.html', APP / 'templates' / 'profile' / 'my_profile.html')
print('copied the profile module, its page and its tests')

MODELS = APP / 'models.py'
raw, crlf, t = read(MODELS)
LINE = 'from .profile_photo_models import ProfilePhoto  # noqa: E402,F401'
if LINE not in t:
    shutil.copy2(MODELS, bdir / 'models.py')
    write(MODELS, t.rstrip('\n') + '\n' + LINE + '\n', crlf)
    print('updated payroll_app/models.py')
URLS = APP / 'urls.py'
raw, crlf, t = read(URLS)
if '_pfp.urlpatterns' not in t:
    shutil.copy2(URLS, bdir / 'urls.py')
    write(URLS, t.rstrip('\n') + '\n\nfrom . import profile_photo as _pfp  # noqa: E402\nurlpatterns += _pfp.urlpatterns\n', crlf)
    print('updated payroll_app/urls.py')

BASE = APP / 'templates' / 'base.html'
raw, crlf, t = read(BASE)
NEW_BLOCK = '''<div class="tb-actions">
        <a class="tb-btn tb-icon" href="{% url 'notifications' %}" title="Notifications" aria-label="Notifications">&#128276;</a>
        <div class="pf" id="pfWrap">
          <button type="button" class="pf-btn" id="pfBtn" aria-haspopup="true" aria-expanded="false" aria-label="Profile menu">
            {% if user.profile_photo %}<img class="pf-img" src="{% url 'profile_photo' user.pk %}?v={{ user.profile_photo.updated_at|date:'U' }}" alt="">{% else %}<span class="pf-initials">{{ user.get_full_name|default:user.username|slice:":1"|upper }}</span>{% endif %}
          </button>
          <div class="pf-menu" id="pfMenu" role="menu">
            <div class="pf-head"><b>{{ user.get_full_name|default:user.username }}</b><small>{% if is_admin_role %}Platform Admin{% else %}{{ user.get_role_display }}{% endif %}{% if user.company %} &middot; {{ user.company.name }}{% endif %}</small></div>
            <a href="{% url 'my_profile' %}" role="menuitem">My Profile</a>
            {% if not is_admin_role and not is_employee_role %}{% url 'settings' as u_acc %}{% if u_acc %}<a href="{{ u_acc }}" role="menuitem">Account Settings</a>{% endif %}{% endif %}
            <a href="{% url 'password_change' %}" role="menuitem">Change Password</a>
            <form method="post" action="{% url 'logout' %}">{% csrf_token %}<button type="submit" role="menuitem">Logout</button></form>
          </div>
        </div>
      </div>'''
if 'id="pfWrap"' not in t:
    pattern = re.compile(r'<div class="tb-actions">.*?</form>\s*</div>', re.S)
    found = pattern.findall(t)
    if len(found) != 1 or 'logout' not in found[0]:
        fail(f'the top bar of base.html is different from what I read ({len(found)} matches). Send me the lines around tb-actions.')
    shutil.copy2(BASE, bdir / 'base.html')
    write(BASE, pattern.sub(lambda m: NEW_BLOCK, t, count=1), crlf)
    print('updated base.html (round profile photo and menu at the top right)')

NEW_MODELS = {'ProfilePhoto'}
mig_dir = APP / 'migrations'
before = {p.name for p in mig_dir.glob('0*.py')}
r = subprocess.run([sys.executable, 'manage.py', 'makemigrations', 'payroll_app', '-n', 'profile_photo'], capture_output=True, text=True, encoding='utf-8', errors='replace')
print((r.stdout or '').strip())
if r.returncode != 0:
    print(r.stderr); fail('makemigrations failed.')
created = sorted({p.name for p in mig_dir.glob('0*.py')} - before)
for name in created:
    tree = ast.parse((mig_dir / name).read_text(encoding='utf-8'))
    ops = [(n.func.attr, ast.unparse(n.keywords[0].value).strip("'\"") if n.keywords else '')
           for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in
           ('CreateModel', 'AddField', 'AlterField', 'RemoveField', 'DeleteModel', 'RenameField', 'AlterModelOptions')]
    bad = [f'{a}:{b}' for a, b in ops if not (a == 'CreateModel' and b in NEW_MODELS)]
    if bad:
        (mig_dir / name).unlink()
        fail('Django wanted to change other tables too (' + ', '.join(bad[:4]) + '). I deleted that migration. Send me this line.')
    print(f'created payroll_app/migrations/{name} (only the profile photo table)')
r = subprocess.run([sys.executable, 'manage.py', 'migrate'], capture_output=True, text=True, encoding='utf-8', errors='replace')
if r.returncode != 0:
    print(r.stderr); fail('migrate failed.')
print('Profile photo and menu installed.')
