"""Installs the Pay Cycle + Working Calendar module into the project (safe to run twice)."""
import ast, pathlib, re, shutil, subprocess, sys, datetime

PACK = pathlib.Path(__file__).resolve().parent
FILES = PACK / 'files'
APP = pathlib.Path('payroll_app')


def fail(msg):
    print('NOTHING FINISHED:', msg); sys.exit(1)


if not pathlib.Path('manage.py').exists() or not APP.is_dir():
    fail('run this from the folder that has manage.py')


def read(p):
    raw = p.read_bytes().decode('utf-8-sig')
    return raw, '\r\n' in raw, raw.replace('\r\n', '\n')


def write(p, text, crlf):
    p.write_bytes((text.replace('\n', '\r\n') if crlf else text).encode('utf-8'))


bdir = pathlib.Path('backups') / ('paycycle_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
bdir.mkdir(parents=True, exist_ok=True)

# ---- 1. the payroll engine: use the pay cycle's dates and working days (two small edits)
ENGINE = APP / 'payroll_engine.py'
raw, crlf, t = read(ENGINE)
HOOK_OLD = ("    days_in_month, lop_days = 0, Decimal('0')\n"
            "    if period:\n"
            "        start, end = period\n")
HOOK_NEW = ("    days_in_month, lop_days = 0, Decimal('0')\n"
            "    cycle_values = None\n"
            "    if period:\n"
            "        from .pay_cycle_calc import cycle_basis\n"
            "        cycle_values = cycle_basis(run, employee, period)     # None unless the run's pay cycle uses working days\n"
            "    if period and cycle_values is not None:\n"
            "        start, end = period\n"
            "        doj = employee.date_of_joining\n"
            "        if doj and doj > end:\n"
            "            return None\n"
            "        days_in_month, not_joined_days, lop_days = cycle_values\n"
            "    elif period:\n"
            "        start, end = period\n")
PERIOD_OLD = "    period = parse_month(run.month)\n    created, skipped = 0, []\n"
PERIOD_NEW = ("    from .pay_cycle_calc import period_for_run\n"
              "    period = period_for_run(run)          # the pay cycle's own dates, or the month label for runs without one\n"
              "    created, skipped = 0, []\n")
engine_done = 'cycle_basis(run, employee, period)' in t
if not engine_done:
    for name, old in (('calculate_line', HOOK_OLD), ('build_run_lines', PERIOD_OLD)):
        if t.count(old) != 1:
            fail(f'payroll_engine.py is different from what I read ({name}: found {t.count(old)} matches). Send me that function.')
    t = t.replace(HOOK_OLD, HOOK_NEW).replace(PERIOD_OLD, PERIOD_NEW)
    try:
        compile(t, 'payroll_engine.py', 'exec')
    except SyntaxError as e:
        fail(f'payroll_engine.py would not compile: {e}')
    shutil.copy2(ENGINE, bdir / 'payroll_engine.py')
    write(ENGINE, t, crlf)
    print('updated payroll_app/payroll_engine.py')
else:
    print('payroll_engine.py already has the pay cycle hook')

# ---- 2. new module files and pages
for name in ('pay_cycle_models.py', 'pay_cycle_calc.py', 'pay_cycles.py', 'tests_pay_cycle.py'):
    shutil.copy2(FILES / name, APP / name)
tdir = APP / 'templates' / 'paycycle'
tdir.mkdir(parents=True, exist_ok=True)
for f in (FILES / 'paycycle_templates').glob('*.html'):
    shutil.copy2(f, tdir / f.name)
print('copied the pay cycle module, 5 pages and its tests')

# ---- 3. register the models and the web addresses (appended at the end of the files)
MODELS = APP / 'models.py'
raw, crlf, t = read(MODELS)
LINE = 'from .pay_cycle_models import WorkingCalendar, CalendarDay, EmployeeCalendar, PayCycle  # noqa: E402,F401'
if LINE not in t:
    shutil.copy2(MODELS, bdir / 'models.py')
    write(MODELS, t.rstrip('\n') + '\n\n' + LINE + '\n', crlf)
    print('updated payroll_app/models.py (registers the new models)')
URLS = APP / 'urls.py'
raw, crlf, t = read(URLS)
if '_pcy.urlpatterns' not in t:
    shutil.copy2(URLS, bdir / 'urls.py')
    write(URLS, t.rstrip('\n') + '\n\nfrom . import pay_cycles as _pcy  # noqa: E402\nurlpatterns += _pcy.urlpatterns\n', crlf)
    print('updated payroll_app/urls.py (adds the pay cycle pages)')

# ---- 4. sidebar links (only when the new sidebar is installed)
BASE = APP / 'templates' / 'base.html'
raw, crlf, t = read(BASE)
if 'sb-group-head' in t and 'working_calendar' not in t:
    A_OLD = ("          {% url 'hr_work_hours' as u_own6 %}{% if u_own6 %}<a href=\"{{ u_own6 }}\"><span class=\"tx\">Working Hours</span></a>{% endif %}\n")
    A_NEW = A_OLD + ("          {% url 'working_calendar' as u_wcal %}{% if u_wcal %}<a href=\"{{ u_wcal }}\"><span class=\"tx\">Working Calendar &amp; Holidays</span></a>{% endif %}\n")
    P_OLD = ("          {% url 'salary_structure' as u_own9 %}{% if u_own9 %}<a href=\"{{ u_own9 }}\"><span class=\"tx\">Salary Structure</span></a>{% endif %}\n")
    P_NEW = ("          {% url 'pay_cycles' as u_pcy %}{% if u_pcy %}<a href=\"{{ u_pcy }}\"><span class=\"tx\">Pay Cycle</span></a>{% endif %}\n") + P_OLD
    if t.count(A_OLD) == 1 and t.count(P_OLD) == 1:
        shutil.copy2(BASE, bdir / 'base.html')
        write(BASE, t.replace(A_OLD, A_NEW).replace(P_OLD, P_NEW), crlf)
        print('updated base.html (Pay Cycle and Working Calendar menu links)')
    else:
        print('NOTE: could not add the menu links to base.html (sidebar text differs). The pages still work at /payroll/pay-cycles/ and /attendance/working-calendar/')
elif 'working_calendar' in t:
    print('menu links are already in base.html')
else:
    print('NOTE: the new sidebar is not installed, so no menu links were added')

# ---- 5. database tables: let Django write the migration, then check it only creates the new tables
NEW_MODELS = {'WorkingCalendar', 'CalendarDay', 'EmployeeCalendar', 'PayCycle'}
mig_dir = APP / 'migrations'
before = {p.name for p in mig_dir.glob('0*.py')}
r = subprocess.run([sys.executable, 'manage.py', 'makemigrations', 'payroll_app', '-n', 'pay_cycles'], capture_output=True, text=True, encoding='utf-8', errors='replace')
print((r.stdout or '').strip())
if r.returncode != 0:
    print(r.stderr); fail('makemigrations failed.')
created = sorted({p.name for p in mig_dir.glob('0*.py')} - before)
if not created:
    print('no new migration needed (tables already exist)')
else:
    for name in created:
        text = (mig_dir / name).read_text(encoding='utf-8')
        tree = ast.parse(text)
        ops = [ast.unparse(n.func).split('.')[-1] + ':' + (ast.unparse(n.keywords[0].value) if n.keywords else '')
               for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in
               ('CreateModel', 'AddField', 'AlterField', 'RemoveField', 'DeleteModel', 'RenameField', 'AlterModelOptions')]
        bad = [o for o in ops if not (o.startswith('CreateModel') and o.split(':', 1)[1].strip("'\"") in NEW_MODELS)]
        if bad:
            (mig_dir / name).unlink()
            fail('Django wanted to change other tables too (' + ', '.join(bad[:4]) + '). I deleted that migration. Send me this line.')
        print(f'created payroll_app/migrations/{name} (only the new pay cycle tables)')
r = subprocess.run([sys.executable, 'manage.py', 'migrate'], capture_output=True, text=True, encoding='utf-8', errors='replace')
print((r.stdout or '').strip().splitlines()[-1] if (r.stdout or '').strip() else '')
if r.returncode != 0:
    print(r.stderr); fail('migrate failed.')
print('Pay cycle module installed.')
