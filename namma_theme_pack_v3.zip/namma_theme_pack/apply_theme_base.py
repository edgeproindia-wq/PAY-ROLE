import pathlib, re, sys, shutil, datetime

if not pathlib.Path('manage.py').exists():
    print('NOTHING WAS CHANGED: run this from the folder that has manage.py'); sys.exit(1)

TPL = pathlib.Path('payroll_app/templates/base.html')
CSS_FILE = pathlib.Path('static/css/namma-theme.css')
JS_FILE = pathlib.Path('static/js/namma-theme.js')
if not TPL.exists():
    print('NOTHING WAS CHANGED: payroll_app/templates/base.html was not found.'); sys.exit(1)
if not CSS_FILE.exists() or not JS_FILE.exists():
    print('NOTHING WAS CHANGED: run Command 1 first - static/css/namma-theme.css and static/js/namma-theme.js are missing.'); sys.exit(1)

ASIDE = r'''<aside class="sidebar" id="sidebar">
    {% url 'employee_home' as u_brand_emp %}<a class="sb-brand" href="{% if is_admin_role %}{% url 'admin_dashboard' %}{% elif is_employee_role and u_brand_emp %}{{ u_brand_emp }}{% else %}{% url 'dashboard' %}{% endif %}">
      <img src="{% static 'img/namma-payroll-logo.png' %}" alt="Namma Payroll" style="height:40px;width:auto;display:block;">
    </a>
    <nav class="sb-nav" aria-label="Main menu">
    {% if is_admin_role %}
      {% url 'admin_dashboard' as u_admin1 %}{% if u_admin1 %}<a class="sb-top" href="{{ u_admin1 }}"><svg class="svg-ic" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg><span class="tx">Dashboard</span></a>{% endif %}
      <div class="sb-group" data-group="platform">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6"/></svg><span class="tx">Platform</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'admin_company_list' as u_admin2 %}{% if u_admin2 %}<a href="{{ u_admin2 }}"><span class="tx">Client Management</span></a>{% endif %}
          {% url 'admin_company_approvals' as u_admin3 %}{% if u_admin3 %}<a href="{{ u_admin3 }}"><span class="tx">Company Approvals</span></a>{% endif %}
          {% url 'admin_demo_requests' as u_admin4 %}{% if u_admin4 %}<a href="{{ u_admin4 }}"><span class="tx">Demo Requests</span></a>{% endif %}
          {% url 'admin_client_complaints' as u_admin5 %}{% if u_admin5 %}<a href="{{ u_admin5 }}"><span class="tx">Client Complaints</span></a>{% endif %}
          {% url 'admin_client_requests' as u_admin6 %}{% if u_admin6 %}<a href="{{ u_admin6 }}"><span class="tx">Client Requests</span></a>{% endif %}
          {% url 'admin_audit_log' as u_admin7 %}{% if u_admin7 %}<a href="{{ u_admin7 }}"><span class="tx">Audit Log</span></a>{% endif %}
        </div>
      </div>
      {% url 'notifications' as u_admin8 %}{% if u_admin8 %}<a class="sb-top" href="{{ u_admin8 }}"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 0 0 4 0"/></svg><span class="tx">Notifications</span></a>{% endif %}
    {% elif is_employee_role %}
      {% url 'employee_home' as u_home %}{% if not u_home %}{% url 'dashboard' as u_home %}{% endif %}<a class="sb-top" href="{{ u_home }}"><svg class="svg-ic" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg><span class="tx">Dashboard</span></a>
      <div class="sb-group" data-group="mypay">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M16 15h2"/></svg><span class="tx">My Pay</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'payslips' as u_emp1 %}{% if u_emp1 %}<a href="{{ u_emp1 }}"><span class="tx">Payslips</span></a>{% endif %}
          {% url 'investment_declaration' as u_emp2 %}{% if u_emp2 %}<a href="{{ u_emp2 }}"><span class="tx">Investment Declaration</span></a>{% endif %}
          {% url 'reimbursement' as u_emp3 %}{% if u_emp3 %}<a href="{{ u_emp3 }}"><span class="tx">Reimbursements</span></a>{% endif %}
        </div>
      </div>
      <div class="sb-group" data-group="selfservice">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg><span class="tx">Self Service</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'attendance' as u_emp4 %}{% if u_emp4 %}<a href="{{ u_emp4 }}"><span class="tx">Attendance</span></a>{% endif %}
          {% url 'leave_management' as u_emp5 %}{% if u_emp5 %}<a href="{{ u_emp5 }}"><span class="tx">Leave</span></a>{% endif %}
          {% url 'grievances' as u_emp6 %}{% if u_emp6 %}<a href="{{ u_emp6 }}"><span class="tx">Grievances</span></a>{% endif %}
          {% url 'announcements' as u_emp7 %}{% if u_emp7 %}<a href="{{ u_emp7 }}"><span class="tx">Announcements</span></a>{% endif %}
          {% url 'ess' as u_emp8 %}{% if u_emp8 %}<a href="{{ u_emp8 }}"><span class="tx">My Profile (ESS)</span></a>{% endif %}
        </div>
      </div>
      {% url 'notifications' as u_emp9 %}{% if u_emp9 %}<a class="sb-top" href="{{ u_emp9 }}"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 0 0 4 0"/></svg><span class="tx">Notifications</span></a>{% endif %}
    {% elif user.is_authenticated %}
      {% url 'dashboard' as u_own1 %}{% if u_own1 %}<a class="sb-top" href="{{ u_own1 }}"><svg class="svg-ic" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg><span class="tx">Dashboard</span></a>{% endif %}
      <div class="sb-group" data-group="people">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3.2-5.5 7-5.5s7 2 7 5.5M16 4.5a3.5 3.5 0 0 1 0 7M18 14.8c2.2.6 4 2.2 4 5.2"/></svg><span class="tx">Employee Management</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'employee_master' as u_own2 %}{% if u_own2 %}<a href="{{ u_own2 }}"><span class="tx">Employee Master</span></a>{% endif %}
          {% url 'hr_employee_import' as u_import %}{% if u_import %}<a href="{{ u_import }}"><span class="tx">Import Employees</span></a>{% endif %}
          {% url 'hr_employee_logins' as u_logins %}{% if u_logins %}<a href="{{ u_logins }}"><span class="tx">Employee Logins</span></a>{% endif %}
          {% url 'user_roles_permissions' as u_own29 %}{% if u_own29 %}<a href="{{ u_own29 }}"><span class="tx">User Roles</span></a>{% endif %}
          {% url 'ess' as u_own28 %}{% if u_own28 %}<a href="{{ u_own28 }}"><span class="tx">ESS</span></a>{% endif %}
        </div>
      </div>
      <div class="sb-group" data-group="attendance">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span class="tx">Attendance</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'attendance' as u_own3 %}{% if u_own3 %}<a href="{{ u_own3 }}"><span class="tx">Attendance</span></a>{% endif %}
          {% url 'hr_shifts' as u_own5 %}{% if u_own5 %}<a href="{{ u_own5 }}"><span class="tx">Shifts</span></a>{% endif %}
          {% url 'hr_work_hours' as u_own6 %}{% if u_own6 %}<a href="{{ u_own6 }}"><span class="tx">Working Hours</span></a>{% endif %}
        </div>
      </div>
      {% url 'leave_management' as u_own4 %}{% if u_own4 %}<a class="sb-top" href="{{ u_own4 }}"><svg class="svg-ic" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg><span class="tx">Leave Management</span></a>{% endif %}
      <div class="sb-group" data-group="payroll">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M16 15h2"/></svg><span class="tx">Salary &amp; Payroll</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'salary_structure' as u_own9 %}{% if u_own9 %}<a href="{{ u_own9 }}"><span class="tx">Salary Structure</span></a>{% endif %}
          {% url 'hr_pay_components' as u_own16 %}{% if u_own16 %}<a href="{{ u_own16 }}"><span class="tx">Other Pay Items</span></a>{% endif %}
          {% url 'payroll_processing' as u_own10 %}{% if u_own10 %}<a href="{{ u_own10 }}"><span class="tx">Payroll Processing</span></a>{% endif %}
          {% url 'arrears' as u_own17 %}{% if u_own17 %}<a href="{{ u_own17 }}"><span class="tx">Arrears</span></a>{% endif %}
          {% url 'full_final_settlement' as u_own18 %}{% if u_own18 %}<a href="{{ u_own18 }}"><span class="tx">Full &amp; Final</span></a>{% endif %}
          {% url 'payslips' as u_own11 %}{% if u_own11 %}<a href="{{ u_own11 }}"><span class="tx">Payslips</span></a>{% endif %}
          {% url 'bank_transfer' as u_own12 %}{% if u_own12 %}<a href="{{ u_own12 }}"><span class="tx">Bank Transfer</span></a>{% endif %}
        </div>
      </div>
      {% url 'reimbursement' as u_own13 %}{% if u_own13 %}<a class="sb-top" href="{{ u_own13 }}"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6"/></svg><span class="tx">Reimbursements</span></a>{% endif %}
      <div class="sb-group" data-group="loans">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg><span class="tx">Loans &amp; Insurance</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'hr_loans' as u_own14 %}{% if u_own14 %}<a href="{{ u_own14 }}"><span class="tx">Loans</span></a>{% endif %}
          {% url 'hr_insurance' as u_own15 %}{% if u_own15 %}<a href="{{ u_own15 }}"><span class="tx">Insurance</span></a>{% endif %}
        </div>
      </div>
      <div class="sb-group" data-group="compliance">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M3 21h18M5 21V10M9 21V10M15 21V10M19 21V10M2 10l10-6 10 6z"/></svg><span class="tx">Compliance</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'statutory_compliance' as u_own19 %}{% if u_own19 %}<a href="{{ u_own19 }}"><span class="tx">Statutory Compliance</span></a>{% endif %}
          {% url 'hr_professional_tax' as u_own20 %}{% if u_own20 %}<a href="{{ u_own20 }}"><span class="tx">Professional Tax</span></a>{% endif %}
          {% url 'income_tax' as u_own21 %}{% if u_own21 %}<a href="{{ u_own21 }}"><span class="tx">Income Tax</span></a>{% endif %}
          {% url 'investment_declaration' as u_own22 %}{% if u_own22 %}<a href="{{ u_own22 }}"><span class="tx">Investment Declaration</span></a>{% endif %}
          {% url 'hr_declarations' as u_own23 %}{% if u_own23 %}<a href="{{ u_own23 }}"><span class="tx">Investment Proofs</span></a>{% endif %}
          {% url 'hr_form16' as u_own24 %}{% if u_own24 %}<a href="{{ u_own24 }}"><span class="tx">Form 16</span></a>{% endif %}
          {% url 'hr_documents' as u_own25 %}{% if u_own25 %}<a href="{{ u_own25 }}"><span class="tx">Tax Documents</span></a>{% endif %}
          {% url 'compliance_reports' as u_own26 %}{% if u_own26 %}<a href="{{ u_own26 }}"><span class="tx">Compliance Reports</span></a>{% endif %}
        </div>
      </div>
      {% url 'reports_analytics' as u_own27 %}{% if u_own27 %}<a class="sb-top" href="{{ u_own27 }}"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg><span class="tx">Reports &amp; Analytics</span></a>{% endif %}
      <div class="sb-group" data-group="engage">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/></svg><span class="tx">Communication</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'grievances' as u_own7 %}{% if u_own7 %}<a href="{{ u_own7 }}"><span class="tx">Grievances</span></a>{% endif %}
          {% url 'announcements' as u_own8 %}{% if u_own8 %}<a href="{{ u_own8 }}"><span class="tx">Announcements</span></a>{% endif %}
          {% url 'notifications' as u_own33 %}{% if u_own33 %}<a href="{{ u_own33 }}"><span class="tx">Notifications</span></a>{% endif %}
        </div>
      </div>
      <div class="sb-group" data-group="settings">
        <button type="button" class="sb-group-head" aria-expanded="false"><svg class="svg-ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg><span class="tx">Settings</span><span class="sb-caret"></span></button>
        <div class="sb-sub">
          {% url 'settings' as u_own30 %}{% if u_own30 %}<a href="{{ u_own30 }}"><span class="tx">Company Settings</span></a>{% endif %}
          {% url 'client_complaints' as u_own31 %}{% if u_own31 %}<a href="{{ u_own31 }}"><span class="tx">Raise Complaint</span></a>{% endif %}
          {% url 'client_requests' as u_own32 %}{% if u_own32 %}<a href="{{ u_own32 }}"><span class="tx">Raise Request</span></a>{% endif %}
        </div>
      </div>
    {% endif %}
    </nav>
    {% if user.is_authenticated %}
    <div class="sb-user">
      <span class="sb-avatar">{{ user.get_full_name|default:user.username|slice:":1"|upper }}</span>
      <div><b>{{ user.get_full_name|default:user.username }}</b><small>{% if is_admin_role %}Platform Admin{% else %}{{ user.get_role_display }}{% endif %}{% if user.company %} &middot; {{ user.company.name }}{% endif %}</small></div>
    </div>
    {% endif %}
    <button type="button" class="sb-collapse" id="sbCollapse">&lsaquo; <span class="tx">Collapse</span></button>
  </aside>
'''

raw = TPL.read_bytes().decode('utf-8-sig')
crlf = '\r\n' in raw
t = raw.replace('\r\n', '\n')

if 'namma-theme.css' in t:
    print('Already applied - nothing to do.'); sys.exit(0)

ASIDE_RE = re.compile(r'<aside class="sidebar"[^>]*>.*?</aside>', re.S)
found = ASIDE_RE.findall(t)
problems = []
if not re.search(r'\{%\s*load[^%]*\bstatic\b', t): problems.append('base.html does not load the static tag')
if t.count('</head>') != 1: problems.append(f'expected exactly 1 </head>, found {t.count("</head>")}')
if t.count('</body>') != 1: problems.append(f'expected exactly 1 </body>, found {t.count("</body>")}')
if len(found) != 1 or 'sb-nav' not in found[0]: problems.append(f'expected exactly 1 sidebar block, found {len(found)}')
if problems:
    print('NOTHING WAS CHANGED:')
    for p in problems: print(' -', p)
    print('base.html is different from what I read. Send me the first 40 lines and the <aside> block of base.html.'); sys.exit(1)

t = ASIDE_RE.sub(lambda m: ASIDE, t, count=1)
t = t.replace('</head>', '<link rel="stylesheet" href="{% static \'css/namma-theme.css\' %}">\n</head>', 1)
t = t.replace('</body>', '<script src="{% static \'js/namma-theme.js\' %}"></script>\n</body>', 1)

bdir = pathlib.Path('backups') / ('theme_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
bdir.mkdir(parents=True, exist_ok=True)
shutil.copy2(TPL, bdir / 'base.html')
TPL.write_bytes((t.replace('\n', '\r\n') if crlf else t).encode('utf-8'))
print('updated payroll_app/templates/base.html (new sidebar, theme stylesheet and script). Old copy saved in', bdir)
