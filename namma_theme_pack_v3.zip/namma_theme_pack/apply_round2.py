import pathlib, re, sys, shutil, datetime

if not pathlib.Path('manage.py').exists():
    print('NOTHING WAS CHANGED: run this from the folder that has manage.py'); sys.exit(1)

APP = pathlib.Path('payroll_app')
TPL = APP / 'templates'
CSS = pathlib.Path('static/css/namma-theme.css')
if not CSS.exists() or 'namma-theme.css' not in (TPL / 'base.html').read_text(encoding='utf-8-sig'):
    print('NOTHING WAS CHANGED: the round 1 theme is not applied yet. Run Command 1 and Command 2 of round 1 first.'); sys.exit(1)

CSS_ADD = '''
/* ROUND 2 - fitted to the real page shell */
body .kpi-card .label{ text-transform:none; letter-spacing:0; font-size:14px; padding-right:46px; }
body .kpi-card .icon-badge{ top:14px; right:14px; box-shadow:0 2px 6px rgba(0,0,0,.14); }
body .kpi-card .delta{ color:rgba(255,255,255,.92) !important; }
body .search-box input{ padding-left:34px; }
body .tb-title{ font-size:18px; font-weight:700; }
body .topbar{ height:64px; padding:0 28px; }
body .content{ padding:24px 28px 56px; }
body .grid-2, body .grid-3{ gap:18px; }
body .card-header .sub{ color:var(--nm-muted); }
body .fx-tag{ border-radius:999px; }
body .steps{ margin:2px 0; }
body .steps .step .dot{ width:30px; height:30px; font-size:12px; border:2px solid #cbd5e1; background:#fff; color:#6b7280; }
body .steps .step.done .dot{ background:var(--nm-primary); border-color:var(--nm-primary); color:#fff; }
body .steps .step.active .dot{ background:#fff; border-color:var(--nm-primary); color:var(--nm-primary-dark); box-shadow:0 0 0 4px rgba(31,147,72,.15); }
body .steps .step .line{ background:#e5e7eb; height:2px; margin:0 10px; }
body .steps .step.done .line{ background:var(--nm-primary); }
body .steps .step .label{ font-weight:600; }
'''

VIEW_OLD = '''    declarations = scope_by_employee_fk(request, InvestmentDeclaration.objects.all())

    context = {
'''
VIEW_NEW = '''    declarations = scope_by_employee_fk(request, InvestmentDeclaration.objects.all())

    # ---- attendance today / last 7 days and recent payroll cost: real data only
    from datetime import timedelta
    today = timezone.localdate()
    active = employees.filter(employment_status='ACTIVE')
    active_ids = set(active.values_list('id', flat=True))
    todays = Attendance.objects.filter(employee_id__in=active_ids, date=today)
    marked_ids = set(todays.values_list('employee_id', flat=True))
    leave_ids = set(leaves.filter(status='APPROVED', from_date__lte=today, to_date__gte=today,
                                  employee_id__in=active_ids).values_list('employee_id', flat=True))
    present_today = todays.filter(status='PRESENT').count()
    absent_today = todays.filter(status='ABSENT').count()
    on_leave_today = len(leave_ids)
    not_marked_today = len(active_ids - marked_ids - leave_ids)
    trend_days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    trend_present = dict(Attendance.objects.filter(employee_id__in=active_ids, date__in=trend_days, status='PRESENT')
                         .values('date').annotate(c=Count('id')).values_list('date', 'c'))
    trend_values = [trend_present.get(d, 0) for d in trend_days]
    cost_runs = list(runs.filter(status='RELEASED', lines__isnull=False).distinct().order_by('-id')[:6])[::-1]
    cost_by_run = dict(PayrollRunLine.objects.filter(payroll_run__in=cost_runs, employee__in=employees)
                       .values('payroll_run').annotate(t=Sum('net_pay')).values_list('payroll_run', 't'))

    context = {
        'present_today': present_today, 'absent_today': absent_today,
        'on_leave_today': on_leave_today, 'not_marked_today': not_marked_today,
        'attendance_trend_labels': _js([d.strftime('%d %b') for d in trend_days]),
        'attendance_trend_values': _js(trend_values), 'attendance_has_data': any(trend_values),
        'cost_labels': _js([r.month for r in cost_runs]),
        'cost_values': _js([float(cost_by_run.get(r.pk, 0) or 0) for r in cost_runs]),
        'cost_has_data': bool(cost_runs),
'''

DASH_EDITS = [
 ('''<div class="card">
  <div class="card-header">
    <div>
      <h3>Latest Payroll Run</h3>''',
  '''<div class="kpi-row">
  <div class="kpi-card">
    <span class="icon-badge" style="background:#fff;color:var(--accent);">&#9989;</span>
    <div class="label">Present Today</div>
    <div class="value">{{ present_today }}</div>
  </div>
  <div class="kpi-card">
    <span class="icon-badge" style="background:#fff;color:var(--info);">&#127796;</span>
    <div class="label">On Leave Today</div>
    <div class="value">{{ on_leave_today }}</div>
  </div>
  <div class="kpi-card">
    <span class="icon-badge" style="background:#fff;color:var(--warn);">&#128221;</span>
    <div class="label">Attendance Not Marked</div>
    <div class="value">{{ not_marked_today }}</div>
  </div>
  <div class="kpi-card">
    <span class="icon-badge" style="background:#fff;color:var(--danger);">&#10060;</span>
    <div class="label">Absent Today</div>
    <div class="value">{{ absent_today }}</div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div>
      <h3>Latest Payroll Run</h3>'''),
 ('''<div class="grid-2">
  <div class="card">
    <div class="card-header"><h3>Employees by Department</h3></div>''',
  '''<div class="grid-2">
  <div class="card">
    <div class="card-header"><div><h3>Attendance - Last 7 Days</h3><div class="sub">Employees marked present each day</div></div></div>
    <div class="card-body">
      {% if attendance_has_data %}<div class="chart-box sm"><canvas id="attTrendChart"></canvas></div>
      {% else %}<div class="empty-state"><div class="icon">&#128197;</div><div class="title">No attendance marked in the last 7 days</div><div class="desc">Mark attendance to see the daily trend here.</div></div>{% endif %}
    </div>
  </div>
  <div class="card">
    <div class="card-header"><div><h3>Payroll Cost - Recent Releases</h3><div class="sub">Net pay of the last released runs</div></div></div>
    <div class="card-body">
      {% if cost_has_data %}<div class="chart-box sm"><canvas id="costChart"></canvas></div>
      {% else %}<div class="empty-state"><div class="icon">&#128176;</div><div class="title">No released payroll yet</div><div class="desc">Release a payroll run to see its cost here.</div></div>{% endif %}
    </div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header"><h3>Employees by Department</h3></div>'''),
 ('''  });
</script>
{% endblock %}''',
  '''  });

  {% if attendance_has_data %}
  new Chart(document.getElementById('attTrendChart'), {
    type: 'bar',
    data: { labels: {{ attendance_trend_labels|safe }}, datasets: [{ label:'Present', data: {{ attendance_trend_values|safe }}, backgroundColor:'#147d39', borderRadius:6, maxBarThickness:36 }] },
    options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ y:{ beginAtZero:true, ticks:{precision:0}, grid:{color:'#eef1f6'} }, x:{ grid:{display:false} } } }
  });
  {% endif %}
  {% if cost_has_data %}
  new Chart(document.getElementById('costChart'), {
    type: 'line',
    data: { labels: {{ cost_labels|safe }}, datasets: [{ label:'Net pay', data: {{ cost_values|safe }}, borderColor:'#147d39', backgroundColor:'rgba(20,125,57,.12)', fill:true, tension:.3, pointRadius:4 }] },
    options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ y:{ beginAtZero:true, grid:{color:'#eef1f6'} }, x:{ grid:{display:false} } } }
  });
  {% endif %}
</script>
{% endblock %}'''),
]

RUN_OLD = '''</div>

<div class="kpi-row">
  <div class="kpi-card"><div class="label">Employees</div>'''
RUN_NEW = '''</div>

<div class="card no-print"><div class="card-body" style="padding:16px 22px;">
  <div class="steps">
    {% with s=run.status %}
    <div class="step {% if s == 'DRAFT' %}active{% else %}done{% endif %}"><span class="dot">{% if s == 'DRAFT' %}1{% else %}&#10003;{% endif %}</span><span class="label">Draft</span><span class="line"></span></div>
    <div class="step {% if s == 'VALIDATED' %}active{% elif s == 'APPROVED' or s == 'RELEASED' %}done{% endif %}"><span class="dot">{% if s == 'APPROVED' or s == 'RELEASED' %}&#10003;{% else %}2{% endif %}</span><span class="label">Validated</span><span class="line"></span></div>
    <div class="step {% if s == 'APPROVED' %}active{% elif s == 'RELEASED' %}done{% endif %}"><span class="dot">{% if s == 'RELEASED' %}&#10003;{% else %}3{% endif %}</span><span class="label">Approved</span><span class="line"></span></div>
    <div class="step {% if s == 'RELEASED' %}done{% endif %}"><span class="dot">{% if s == 'RELEASED' %}&#10003;{% else %}4{% endif %}</span><span class="label">Released</span></div>
    {% endwith %}
  </div>
</div></div>

<div class="kpi-row">
  <div class="kpi-card"><div class="label">Employees</div>'''

def load(p):
    raw = p.read_bytes().decode('utf-8-sig')
    return raw, ('\r\n' in raw), raw.replace('\r\n', '\n')

targets = {
    'views': (APP / 'views.py', [(VIEW_OLD, VIEW_NEW)]),
    'dash': (TPL / 'Dashboard.html', DASH_EDITS),
    'run': (TPL / 'Payroll' / 'Payroll Run Detail.html', [(RUN_OLD, RUN_NEW)]),
}
css_text = CSS.read_text(encoding='utf-8-sig')
if 'ROUND 2' in css_text and 'present_today' in (APP / 'views.py').read_text(encoding='utf-8-sig'):
    print('Already applied - nothing to do.'); sys.exit(0)

plans, problems = {}, []
for key, (p, edits) in targets.items():
    if not p.exists():
        problems.append(f'{p.as_posix()}: file not found'); continue
    raw, crlf, t = load(p)
    for old, new in edits:
        n = t.count(old)
        if n != 1:
            problems.append(f'{p.name}: expected exactly 1 match, found {n} for: {old.strip().splitlines()[0][:60]}')
        else:
            t = t.replace(old, new)
    plans[key] = (p, t, crlf)
if problems:
    print('NOTHING WAS CHANGED:')
    for x in problems: print(' -', x)
    print('A file is different from what I read. Send me the lines it complains about.'); sys.exit(1)
try:
    compile(plans['views'][1], 'views.py', 'exec')
except SyntaxError as e:
    print('NOTHING WAS CHANGED: views.py would not compile:', e); sys.exit(1)

bdir = pathlib.Path('backups') / ('round2_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
bdir.mkdir(parents=True, exist_ok=True)
for key, (p, t, crlf) in plans.items():
    shutil.copy2(p, bdir / p.name)
    p.write_bytes((t.replace('\n', '\r\n') if crlf else t).encode('utf-8'))
    print('updated', p.as_posix())
shutil.copy2(CSS, bdir / CSS.name)
if 'ROUND 2' not in css_text:
    CSS.write_bytes((css_text.rstrip('\n') + '\n' + CSS_ADD).encode('utf-8'))
    print('updated', CSS.as_posix())
print('Old copies saved in', bdir)
