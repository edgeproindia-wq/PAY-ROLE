"""Namma Payroll - UI theme installer (round 1 + round 2).

Run it from the project folder with the virtual environment active:
    python <path-to>\\install.py
Options:  --quick   run only the new tests instead of the full suite
          --no-git  do not commit or push
Nothing is pushed unless every check and test passes."""
import os, pathlib, shutil, subprocess, sys

PACK = pathlib.Path(__file__).resolve().parent
FILES = PACK / 'files'
DEFAULT_PROJECT = r'C:\edgepro_working_copy\payroll_professional_theme_and_templates'
QUICK = '--quick' in sys.argv
NO_GIT = '--no-git' in sys.argv


def stop(msg):
    print()
    print('STOP - ' + msg)
    print('Nothing was pushed.')
    sys.exit(1)


def run(args, capture=False):
    return subprocess.run(args, capture_output=capture, text=True, encoding='utf-8', errors='replace')


def step(n, text):
    print()
    print(f'[{n}] {text}')


if not pathlib.Path('manage.py').exists():
    if pathlib.Path(DEFAULT_PROJECT, 'manage.py').exists():
        os.chdir(DEFAULT_PROJECT)
    else:
        stop('manage.py not found. Open PowerShell in your project folder first.')
PROJECT = pathlib.Path.cwd()
print('Project folder:', PROJECT)

step(1, 'Copying the style files into the project')
(PROJECT / 'static' / 'css').mkdir(parents=True, exist_ok=True)
(PROJECT / 'static' / 'js').mkdir(parents=True, exist_ok=True)
shutil.copy2(FILES / 'namma-theme.css', PROJECT / 'static' / 'css' / 'namma-theme.css')
shutil.copy2(FILES / 'namma-theme.js', PROJECT / 'static' / 'js' / 'namma-theme.js')
print('  static/css/namma-theme.css and static/js/namma-theme.js are in place')

step(2, 'Installing the new sidebar into base.html')
r = run([sys.executable, str(PACK / 'apply_theme_base.py')])
if r.returncode != 0:
    stop('the sidebar patch did not apply. Copy the lines above and send them to me.')

step(3, 'Adding the dashboard cards and the payroll run tracker')
r = run([sys.executable, str(PACK / 'apply_round2.py')])
if r.returncode != 0:
    stop('the dashboard patch did not apply. Copy the lines above and send them to me.')

step(4, 'Installing the Pay Cycle and Working Calendar module (new database tables)')
r = run([sys.executable, str(PACK / 'apply_paycycle.py')])
if r.returncode != 0:
    stop('the Pay Cycle module did not install. Copy the lines above and send them to me.')

step(5, 'Installing the round profile photo and profile menu (new database table)')
r = run([sys.executable, str(PACK / 'apply_profile.py')])
if r.returncode != 0:
    stop('the profile photo module did not install. Copy the lines above and send them to me.')

step(6, 'Adding the tests')
shutil.copy2(FILES / 'tests_theme.py', PROJECT / 'payroll_app' / 'tests_theme.py')
shutil.copy2(FILES / 'tests_round2.py', PROJECT / 'payroll_app' / 'tests_round2.py')
print('  tests are in place')

step(7, 'Checking the project')
if run([sys.executable, 'manage.py', 'check']).returncode != 0:
    stop('python manage.py check failed.')
code = ("from django.template.loader import get_template; "
        "[get_template(n) for n in ('base.html','Dashboard.html','Payroll/Payroll Run Detail.html','paycycle/list.html','paycycle/detail.html','paycycle/calendar.html','profile/my_profile.html')]; print('templates load OK')")
if run([sys.executable, 'manage.py', 'shell', '-c', code]).returncode != 0:
    stop('a template has an error.')

step(8, 'Running the new tests only (quick)' if QUICK else 'Running the FULL test suite - this takes several minutes, please wait')
targets = ['payroll_app.tests_theme', 'payroll_app.tests_round2', 'payroll_app.tests_pay_cycle', 'payroll_app.tests_profile'] if QUICK else ['payroll_app']
if not QUICK:
    print('  About 250 tests will run. You will see the count going up. Please do NOT press Ctrl+C or close this window.')
import time
log = PROJECT / 'theme_install_test_log.txt'
started = time.time()
done = 0
proc = None
try:
    proc = subprocess.Popen([sys.executable, 'manage.py', 'test', '-v', '2'] + targets, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', bufsize=1)
    with open(log, 'w', encoding='utf-8', errors='replace') as fh:
        for line in proc.stdout:
            fh.write(line)
            if line.rstrip().endswith((' ... ok', ' ... FAIL', ' ... ERROR', ' ... skipped')) or ' ... skipped ' in line:
                done += 1
                if done % 5 == 0:
                    secs = int(time.time() - started)
                    print(f'  {done} tests finished ({secs // 60} min {secs % 60:02d} s)', flush=True)
    proc.wait()
except KeyboardInterrupt:
    if proc is not None:
        proc.kill()
    print()
    print('You stopped the tests, so nothing was pushed. Run the installer again: it skips the finished steps and only repeats the tests.')
    sys.exit(1)
output = log.read_text(encoding='utf-8', errors='replace')
tail = [l for l in output.strip().splitlines() if l.strip()][-6:]
for l in tail:
    print('  ' + l)
failed = [l for l in output.splitlines() if l.startswith(('ERROR:', 'FAIL:'))]
if failed:
    print()
    print('FAILING TESTS:')
    for l in failed: print('  ' + l)
    stop('some tests failed. Send me the last 40 lines of theme_install_test_log.txt (in the project folder).')
if not any(l.strip() == 'OK' or l.startswith('OK') for l in tail):
    stop('the tests did not finish OK. Send me the last 40 lines of theme_install_test_log.txt.')
log.unlink()
print('  all tests passed')

if NO_GIT:
    print()
    print('DONE (no git step requested).')
    sys.exit(0)

step(9, 'Saving to GitHub (Render deploys from there)')
paths = ['payroll_app/views.py', 'payroll_app/models.py', 'payroll_app/urls.py', 'payroll_app/payroll_engine.py',
         'payroll_app/templates/base.html', 'payroll_app/templates/Dashboard.html',
         'payroll_app/templates/Payroll/Payroll Run Detail.html', 'payroll_app/templates/paycycle',
         'payroll_app/templates/profile', 'payroll_app/migrations',
         'payroll_app/pay_cycle_models.py', 'payroll_app/pay_cycle_calc.py', 'payroll_app/pay_cycles.py',
         'payroll_app/profile_photo_models.py', 'payroll_app/profile_photo.py',
         'static/css/namma-theme.css', 'static/js/namma-theme.js',
         'payroll_app/tests_theme.py', 'payroll_app/tests_round2.py', 'payroll_app/tests_pay_cycle.py', 'payroll_app/tests_profile.py']
if run(['git', 'add', '--'] + paths).returncode != 0:
    stop('git add failed.')
staged = run(['git', 'diff', '--cached', '--name-only'], capture=True).stdout.strip()
print('  files to be committed:')
for l in staged.splitlines(): print('   ', l)
if not staged:
    print('  nothing new to commit - already saved.')
    sys.exit(0)
if run(['git', 'commit', '-m', 'UI theme + Pay Cycle & Working Calendar + profile photo menu']).returncode != 0:
    stop('git commit failed.')
if run(['git', 'push']).returncode != 0:
    stop('git push failed. The files are saved on your PC; send me the lines above.')
run(['git', 'fetch', 'origin'])
local = run(['git', 'log', '-1', '--format=%h %s'], capture=True).stdout.strip()
remote = run(['git', 'log', 'origin/main', '-1', '--format=%h %s'], capture=True).stdout.strip()
print('  Local  :', local)
print('  GitHub :', remote)
print()
print('DONE. Render now deploys automatically. Watch Events until it says Live, then press Ctrl+F5 on the site.')
